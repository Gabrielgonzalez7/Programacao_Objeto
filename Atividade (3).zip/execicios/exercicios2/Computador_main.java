package exercicios2;
import java.util.Scanner;
import exercicios.Carro;

public class Computador_main {

	public static void main(String[] args) {
		Computador c = new Computador();
		Computador c2 = new Computador();
		Scanner sc = new Scanner(System.in);
		
		
		//Primeiro
		System.out.println("Digite a Marca do computador: ");
		c.marca = sc.nextLine();
		System.out.println("Digite o modelo do computador: ");
		c.modelo = sc.nextLine();
		System.out.println("Digite o tipo do computado: ");
		c.tipo = sc.nextLine();
		System.out.println("Digite o preço do computador: ");
		c.preco = sc.nextDouble();
		
		// Segundo:
		
		c2.marca = "Samsung";
		c2.modelo= "Galaxy TavA9+";
		c2.tipo= "Tablet";
		c2.preco=  (double) 1259;
		
		System.out.println("A marca do computador é: " +c2.marca);
		System.out.println("O modelo do computador é: " +c2.modelo);
		System.out.println("O tipo do computador é: " +c2.tipo);
		System.out.println("O preço do computador é: " +c2.preco);
		
		
		
		
		
	}

}
