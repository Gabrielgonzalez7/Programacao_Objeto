package exercicios3;
import java.util.Scanner;

import pkg.Pessoa;
public class Pessoa_main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Pessoa p = new Pessoa(); 
		System.out.println("Digite seu nome: ");
		p.nome = sc.nextLine();
		System.out.println("Digite seu sexo: ");
		p.sexo = sc.nextLine();
		System.out.println("Digite sua idade:");
		p.idade = sc.nextInt();
		
	}

}
