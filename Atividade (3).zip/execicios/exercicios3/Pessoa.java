package exercicios3;

public class Pessoa {
	public String nome;
	public String sexo; 
	public int idade;
	
}
