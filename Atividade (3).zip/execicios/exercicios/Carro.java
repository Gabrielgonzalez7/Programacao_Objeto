package exercicios;

public class Carro {
	public String marca;
	public String modelo;
	public int ano;
}

