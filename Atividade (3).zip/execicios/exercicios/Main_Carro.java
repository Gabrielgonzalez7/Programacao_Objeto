package exercicios;
import java.util.Scanner;
import pkg.Pessoa;

public class Main_Carro {

	public static void main(String[] args) {
		Carro c = new Carro();
		c.marca = "Toyota";
		c.modelo = "Corrolla";
		c.ano = 2015;
		System.out.println("A marca do carro é: " +c.marca);
		System.out.println("O modelo do carro é: " +c.modelo);
		System.out.println("O ano do carro é: " +c.ano);
		 System.out.println();
		
		 //Segundo carro
		Carro c2 = new Carro();
		c2.marca = "Volkswagen";
		c2.modelo = "T-Cross";
		c2.ano = 2024;
		System.out.println("A marca do carro 2 é: " +c2.marca);
		System.out.println("O modelo do carro 2 é: " +c2.modelo);
		System.out.println("O ano do carro 2 é: " +c2.ano);
		
		System.out.println();
		//usuario digita o 3 carro:
		
		Scanner sc = new Scanner(System.in);
		Carro c3 = new Carro();
		System.out.println("Digite a Marca do carro: ");
		c3.marca = sc.nextLine();
		System.out.println("Digite o Modelo do carro: ");
		c3.modelo = sc.nextLine();
		System.out.println("Digite o Ano do carro: ");
		c3.ano = sc.nextInt();
	}
}
