package pkg3;

public class Livro {
public String autor;
public String titulo;
public int ano;
}
