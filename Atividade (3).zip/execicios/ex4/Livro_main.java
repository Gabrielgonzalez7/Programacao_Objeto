package pkg3;
import java.util.Scanner;
public class Livro_main {

	public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
			Livro l = new Livro();
			System.out.println("Digite o autor do Livro: ");
			l.autor = sc.nextLine();
			System.out.println("Digite o titulo di Livro:  ");
			l.titulo = sc.nextLine();
			System.out.println("Digite o ano do Livro: ");
			l.ano = sc.nextInt();
		}
	}

