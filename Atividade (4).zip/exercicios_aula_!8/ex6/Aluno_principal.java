package AULA18_03;
import java.util.Scanner;
public class Aluno_principal {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Aluno a = new Aluno();
		
		//aluno 1
		System.out.println("Digite o nome do Aluno: ");
		a.nome = sc.nextLine();
		System.out.println();
		System.out.println("Digite a data em que o aluno nasceu: ");
		a.nascimento = sc.nextLine();
		System.out.println("Digite o ano em que o aluno ingressou na instituição: ");
		a.ano = sc.nextInt();
		System.out.println();
		System.out.println("Digite o número da matricula do aluno: ");
		a.matricula = sc.nextInt();
		System.out.println();
		System.out.println("Digite o ano em que o aluno nasceu: ");
		a.nascimento = sc.nextLine();
		
		a.exibir_dados();
		
		
		
		
		
		
		
		

	}

}
