package AULA18_03;

public class Aluno {
	public String nome;
	public String nascimento;
	public int matricula;
	public int ano;
	

			public void exibir_dados() {
				System.out.println("O nome do aluno é: " +nome);
				System.out.println();
				System.out.println("A data de nascimento do aluno é: " +nascimento);
				System.out.println();
				System.out.println("O número da matricula é: " +matricula);
				System.out.println();
				System.out.println("O ano que o aluno ingressou na faculdade: " +ano);
				System.out.println();
}
			}