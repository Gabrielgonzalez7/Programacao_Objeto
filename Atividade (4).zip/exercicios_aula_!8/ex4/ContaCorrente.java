package pkg;

import java.util.Scanner;

public class ContaCorrente {
	float saldo;
	boolean sacar;
	
	//Método para ler o saldo inicial
	public void definirSaldoInicial (Scanner teclado) {
		System.out.println("Digite o saldo inicial: R$");
		saldo = teclado.nextFloat();
		System.out.println("Saldo atual: R$" + saldo);
	}
	
	//Método para depósito
	public void depositarValor (Scanner teclado) {
		System.out.println("\nDigite o valor que deseja depositar: R$");
		saldo = saldo + teclado.nextFloat();
		System.out.println("Saldo atual: R$" + saldo);
	}
	
	//Método para saque
	public boolean sacarValor (Scanner teclado) {
		System.out.println("\nDigite o valor que deseja sacar: R$");
		float saque = teclado.nextFloat();
		if(saque > saldo) {
			System.out.println("Saldo insuficiente!");
			System.out.println("Saldo atual: R$" + saldo);
			sacar = false;
		} else {
			saldo = saldo - saque;
			System.out.println("Saldo atual: R$" + saldo);
			sacar = true;
		}
		
		return sacar;
	}
}
