package pkg;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		ContaCorrente novaConta = new ContaCorrente();
		
		novaConta.definirSaldoInicial(teclado);
		novaConta.sacarValor(teclado);
		novaConta.depositarValor(teclado);
		novaConta.sacarValor(teclado);

	}

}
