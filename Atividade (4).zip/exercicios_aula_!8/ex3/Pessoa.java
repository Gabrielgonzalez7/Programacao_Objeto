package pkg;

public class Pessoa {
	String nome;
	String email;
	String dataNascimento;
	String endereco;
	boolean admin;
	
	//Método para armazenar os dados
	public void infoPessoa(String nome, String email, String dataNascimento, String endereco) {
		this.nome = nome;
		this.email = email;
		this.dataNascimento = dataNascimento;
		this.endereco = endereco;
	}
	
	//Método para exibir o email
	public String exibirEmail() {
		return email;
	}
	
	//Método para promover a administrador
	public void promoverAdmin() {
		admin = true;
		System.out.println(nome + " agora é administrador.");
	}
	
}
