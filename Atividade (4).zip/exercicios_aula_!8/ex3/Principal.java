package pkg;

public class Principal {

	public static void main(String[] args) {
		//Cria a primeira pessoa
		Pessoa p1 = new Pessoa();
		
		//Armazena as informações
		p1.infoPessoa("Andrisa", "andrisa.santos", "11/01/05", "Santa Maria/RS");
		
		//Exibe o email
		System.out.println("\nEmail de " + p1.nome + ": " + p1.exibirEmail());
		
		//Promove a administrador
		p1.promoverAdmin();
		
		//Cria a segunda pessoa
		Pessoa p2 = new Pessoa();
		
		p2.infoPessoa("Nadine", "nadine.santos", "06/03/15", "São Sepé/RS");
		
		p2.exibirEmail();System.out.println("\nEmail de " + p2.nome + ": " + p2.exibirEmail());
	}

}
