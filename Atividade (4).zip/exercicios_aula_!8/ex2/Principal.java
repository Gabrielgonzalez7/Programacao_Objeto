package pkg;
import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		//Criar um objeto tipo livro
		Livro livro1 = new Livro();
		
		//Ler as informações do livro
		System.out.println("*Cadastro de Livro*");
		System.out.print("Digite o título do livro: ");
        String titulo = teclado.nextLine();
        
        System.out.print("Digite o autor do livro: ");
        String autor = teclado.nextLine();

        System.out.print("Digite o ano de publicação: ");
        int ano = teclado.nextInt();
        teclado.nextLine(); // Limpar o teclado

        System.out.print("Digite o gênero do livro: ");
        String genero = teclado.nextLine();
        
        //Exibir as informações do livro
        livro1.infoLivro(titulo, autor, ano, genero);
        
        //Testar empréstimo
        livro1.emprestimo(teclado);
        
        //Testar devolução
        livro1.devolucao(teclado);
        
        //Fechar o teclado
        teclado.close();

	}

}
