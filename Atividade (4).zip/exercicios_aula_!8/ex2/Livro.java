package pkg;
import java.util.Scanner;

public class Livro {
	String titulo;
	String autor;
	int anoPublicacao;
	String genero;
	boolean emprestado = false;
	Scanner teclado = new Scanner(System.in);
	
	//Método para exibir as informações do livro
	public void infoLivro (String titulo, String autor, int anoPublicacao, String genero) {
		System.out.println("\n*Informações do Livro*\n");
		System.out.println("Título: " + titulo);
		System.out.println("Autor: " + autor);
		System.out.println("Ano de publicação: " + anoPublicacao);
		System.out.println("Gênero: " + genero);
	}
	
	//Controle de empréstimo
	public void emprestimo (Scanner teclado) {
		System.out.println("\nConsultar situação");
		if(emprestado == true)
			System.out.println("Livro indisponível!! Deseja outro livro?");
		else {
			System.out.println("Disponível para empréstimo! ");
			System.out.println("Deseja fazer o empréstimo?");
			System.out.println("1 - Sim\t 2 - Não");
			int fazerEmprestimo = teclado.nextInt();
			teclado.nextLine();
			
			if(fazerEmprestimo == 1) {
				emprestado = true;
				System.out.println("Livro emprestado!\nBoa leitura :)");
			} else if(fazerEmprestimo == 2) {
				System.out.println("Aé logo...");
			} else {
				System.out.println("Opção inválida.");
			}
		}
	}
	
	//Método para controlar devolução
	public void devolucao (Scanner teclado) {
		System.out.println("\nConsultar situação");
		if(emprestado == true) {
			System.out.println("Livro indisponível para empréstimo!");
			System.out.println("1 - Sim\t 2 - Não");
			int fazerDevolucao = teclado.nextInt();
			teclado.nextLine();
			
			if(fazerDevolucao == 1) {
				emprestado = false;
				System.out.println("Livro devolvido!");
			} else if(fazerDevolucao == 2) {
				System.out.println("\Até logo!");
			} else {
				System.out.println("Opção inválida.");
			}
		}
		else 
			System.out.println("Disponível para empréstimo! ");
	}
	
}
