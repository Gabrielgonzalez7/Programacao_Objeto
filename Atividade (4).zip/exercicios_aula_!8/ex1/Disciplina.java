package AULA18_03;

public class Disciplina {
	public String nome_professor;
	public String nome_disciplina;
	public int carga_horario;
	public void exibirDados() {
		System.out.println("Nome da Disciplina: " +nome_disciplina);
		System.out.println("Nome do professor: " +nome_professor);
		System.out.println("Carga horária da disciplina: " +carga_horario + " Horas");
	}
	
}
