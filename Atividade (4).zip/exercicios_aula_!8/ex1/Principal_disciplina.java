package AULA18_03;
import java.util.Scanner;

public class Principal_disciplina {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Disciplina d = new Disciplina();
		
		// Primeiro professor
		
		d.nome_disciplina = "Estrutura de Dados";
		d.nome_professor = "Alexandre Zamberlan";
		d.carga_horario = 80;
		
		System.out.println("A Disciplina é: " +d.nome_disciplina);
		System.out.println("O nome do professor é: " +d.nome_professor);
		System.out.println("A carga horária é : " +d.carga_horario + " Horas");
		
		
		d.exibirDados();
		//Segundo Professor
		
		System.out.println("Disciplina 2: ");
		
		Disciplina d2 = new Disciplina();
		
		System.out.println("Digite o nome da Disciplina: ");
		d2.nome_disciplina = sc.nextLine();
		
		System.out.println("Digite o nome do Professor: ");		
		d2.nome_professor = sc.nextLine();
		
		System.out.println("Digite a carga horária da Disciplina: ");
		d2.carga_horario = sc.nextInt();
		
		d2.exibirDados();
		
	}

}
