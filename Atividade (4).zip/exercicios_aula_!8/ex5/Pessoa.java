package aula;

public class Pessoa {
	public String nome_pessoa;
	public int idade_pessoa;
	
	public void exibir_dados() {
		System.out.println("O nome do aluno é: " +nome_pessoa);
		System.out.println("A idade do aluno é: " +idade_pessoa);
	}

	public void setNome(String nextLine) {
		// TODO Auto-generated method stub
		
	}

	public void setIdade(int nextInt) {
		// TODO Auto-generated method stub
		
	}
}
