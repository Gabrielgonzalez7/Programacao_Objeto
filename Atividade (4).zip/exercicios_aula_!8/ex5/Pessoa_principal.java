package aula;

	import java.util.Scanner;

	public class Pessoa_principal {
	    public static void main(String[] args) {
	        Scanner teclado = new Scanner(System.in);
	        Pessoa P = new Pessoa(); 

	        System.out.println("Escolha uma opção: \n1 - Definir Nome \n2 - Definir Idade");
	        int escolha = teclado.nextInt();
	        teclado.nextLine(); 
	        // Escolha do usuário
	        switch (escolha) {
	            case 1:
	                System.out.println("Digite o nome do aluno: ");
	                P.setNome(teclado.nextLine()); 
	                break;
	            case 2:
	                System.out.println("Digite a idade do aluno: ");
	                P.setIdade(teclado.nextInt()); 
	                break;
	            default:
	                System.out.println("Opção inválida.");
	        }

	        P.exibir_dados();
	        teclado.close(); 
	    }
	}

