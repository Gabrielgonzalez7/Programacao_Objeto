package pkg;

public class aula_2 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
	int i; 
		for(int = 0;int < 10;i++) {
		System.out.println(i);
	}	
	}
