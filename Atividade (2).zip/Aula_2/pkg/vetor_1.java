package pkg;

public class vetor_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] vetor = new int[5];
		vetor[0] = 6;
		vetor[1] = 7;
		vetor[2] = 8;
		vetor[3] = 2;
		vetor[4] = 5;
		for(int i= 0; i<5; i++) {
			System.out.print(" Elemento "+i+": ");
			System.out.println(vetor[i]);
		}
	}

}
