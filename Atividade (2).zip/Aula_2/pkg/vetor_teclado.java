package pkg;

import java.util.Scanner;
public class vetor_teclado {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] vetor = new int[5];
		Scanner sc = new Scanner(System.in);
		for(int i= 0; i<5; i++) {
			System.out.print("Digite o Elemento "+i+" :");
			vetor[i] = sc.nextInt();
		}
		for(int i= 0; i<5; i++) {
			System.out.print(" Elemento "+i+": ");
			System.out.println(vetor[i]);
		}
	}

}
