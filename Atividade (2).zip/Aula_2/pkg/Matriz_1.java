package pkg;
import java.util.Scanner;

public class Matriz_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int[] vetorDinamico; 
		int tam;
		System.out.print("Digite o tamanho do vetor: ");
		tam = sc.nextInt();
		vetorDinamico = new int[tam];
		for(int i=0; i < tam; i++) {
			System.out.print("Digite o elemento "+i+" :");
			vetorDinamico[i] = sc.nextInt();
		}
		for(int i=0; i < tam; i++) {
			System.out.print("Elemento "+i+" :");
			System.out.println(vetorDinamico[i]);
		}
	}

}
