package matriz;

public class Matriz_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
