package ex1;

public class ex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i =0; i<11;i++) {
			System.out.println(i);
		}
	}

}
