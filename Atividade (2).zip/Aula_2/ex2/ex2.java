package ex2;

public class ex2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=0;i<21;i++) {
			if(i%2==0) {
						System.out.println(i);
		}
		}
	}

}
