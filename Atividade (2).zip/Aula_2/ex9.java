package pkg;

public class ex9 {

    public static void main(String[] args) {
        System.out.println("Números primos de 1 a 50:");

        for (int numero = 1; numero <= 50; numero++) {
            if (ehPrimo(numero)) {
                System.out.println(numero);
            }
        }
    }
    public static boolean ehPrimo(int numero) {
        if (numero <= 1) {
            return false;
        }

        for (int i = 2; i <= Math.sqrt(numero); i++) {
            if (numero % i == 0) {
                return false;
            }
        }

        return true;
    }
}