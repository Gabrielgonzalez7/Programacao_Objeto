package pkg;
import java.util.Scanner;
public class ex6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		int numero;
		System.out.println("Digite um número inteiro (0 para encerrar)");
		
		do {
			System.out.print("digite um numero inteiro: ");
			numero = scanner.nextInt();
			
			if(numero !=0) {
				System.out.println("Você digitou: " +numero);
			}
		} while (numero !=0);
		System.out.println("Você digitou 0 e o programa foi encerrado!");
	}

}
