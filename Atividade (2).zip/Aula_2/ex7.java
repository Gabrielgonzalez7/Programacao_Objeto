package pkg;
import java.util.Scanner;
public class ex7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		double nota;
		double somaNotas = 0;
		int quantidadedeNotas = 0;
		System.out.println("Digite a nota dos alunos (-1 para encerrar)");
	
		while(true) {
			System.out.println("digite a nota do aluno: ");
			nota = scanner.nextDouble();
			if (nota == -1) {
				break;
			}
			if(nota >= 0 && nota <= 10) {
				somaNotas += nota;
				quantidadedeNotas++;
			} else {
				System.out.println("Nota Inválida!! Digite uma nota entre 0 e 10");
			}
		}
		if(quantidadedeNotas > 0) {
			double media = somaNotas / quantidadedeNotas;
			System.out.println("Quantidade de notas válidas: " +quantidadedeNotas);
			System.out.println("media das notas: " +media);
		}else {
			System.out.println("Nenhuma nota válida foi inserida.");
		}
	
	
	
	}

}
