package pkg;
import java.util.Scanner;
public class ex8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		String cidade;
		System.out.println("Digite o nome de uma cidade: (São Paulo para encerrar)")
;
		while(true) {
			System.out.println("Cidade: ");
			cidade = scanner.nextLine();
			if(cidade.equalsIgnoreCase("São Paulo")) {
				System.out.println("Cidade escolhida São Paulo, então programa foi encerrado!!");
				break;
			}
			 System.out.println("Você digitou: " +cidade);
		}
	}

}
