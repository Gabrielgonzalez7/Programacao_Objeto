// Classe Aluno
public class Aluno {
    String nome;
    double notaFinal;

    // Construtor
    public Aluno(String nome, double notaFinal) {
        this.nome = nome;
        this.notaFinal = notaFinal;
    }
}

